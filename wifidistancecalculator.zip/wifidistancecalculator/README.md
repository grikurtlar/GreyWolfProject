# Wifi Distance Calculater
   >This basic calculator is based on the formula
   >**distance = 10 ^ ((27.55 - (20 * log10(frequency)) + signalLevel)/20)**
   > where frequency is in Mhz, signal level is in dBm and distance is in meters.
   
